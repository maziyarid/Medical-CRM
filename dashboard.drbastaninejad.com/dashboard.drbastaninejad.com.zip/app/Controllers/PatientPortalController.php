<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Core\Request;

final class PatientPortalController extends Controller
{
    public function overview(Request $req): array
    {
        $patientId = (int)$req->user['id'];
        $clinicId = (int)$req->user['clinic_id'];
        $db = Database::conn();

        $stmt = $db->prepare(
            'SELECT a.id, a.scheduled_at, a.duration_minutes, a.visit_reason, a.status
             FROM appointments a
             WHERE a.patient_id = ? AND a.clinic_id = ? AND a.deleted_at IS NULL
               AND a.scheduled_at > UTC_TIMESTAMP() AND a.status IN ("scheduled","confirmed")
             ORDER BY a.scheduled_at ASC LIMIT 1'
        );
        $stmt->execute([$patientId, $clinicId]);
        $next = $stmt->fetch();

        $stmt = $db->prepare('SELECT COUNT(*), MAX(created_at) FROM intakes WHERE patient_id = ? AND deleted_at IS NULL');
        $stmt->execute([$patientId]);
        [$totalIntakes, $lastIntakeDate] = $stmt->fetch(\PDO::FETCH_NUM) ?: [0, null];

        $stmt = $db->prepare('SELECT COUNT(*) FROM media WHERE patient_id = ? AND clinic_id = ? AND deleted_at IS NULL');
        $stmt->execute([$patientId, $clinicId]);
        $totalDocuments = (int)$stmt->fetchColumn();

        return $this->success([
            'patient_name' => (string)($req->user['name'] ?? ''),
            'next_appointment' => $next ? [
                'appointment_id' => (int)$next['id'],
                'scheduled_at' => $next['scheduled_at'],
                'duration_minutes' => (int)$next['duration_minutes'],
                'reason' => $next['visit_reason'],
                'status' => $next['status'],
            ] : null,
            'total_intakes' => (int)$totalIntakes,
            'total_documents' => $totalDocuments,
            'last_intake_date' => $lastIntakeDate,
        ]);
    }

    public function profile(Request $req): array
    {
        $stmt = Database::conn()->prepare(
            'SELECT id, uuid, first_name, last_name, father_name, mobile, email, home_tel,
                    national_id, birth_date, birth_date_jalali, gender, insurance_number,
                    insurance_status, home_address
             FROM patients WHERE id = ? AND deleted_at IS NULL LIMIT 1'
        );
        $stmt->execute([(int)$req->user['id']]);
        $row = $stmt->fetch();
        if (!$row) {
            return $this->error('بیمار یافت نشد', 404);
        }
        return $this->success([
            'id' => (int)$row['id'],
            'uuid' => $row['uuid'],
            'first_name' => $row['first_name'],
            'last_name' => $row['last_name'],
            'father_name' => $row['father_name'],
            'mobile' => $row['mobile'],
            'email' => $row['email'],
            'home_tel' => $row['home_tel'],
            'national_id' => $row['national_id'],
            // Canonical UI expects a Jalali string in birth_date.
            'birth_date' => $row['birth_date_jalali'] ?: $row['birth_date'],
            'birth_date_gregorian' => $row['birth_date'],
            'birth_date_jalali' => $row['birth_date_jalali'],
            'gender' => $row['gender'],
            'insurance_number' => $row['insurance_number'],
            'insurance_status' => $row['insurance_status'],
            'home_address' => $row['home_address'],
        ]);
    }

    public function updateProfile(Request $req): array
    {
        $in = $req->body;
        $updates = [];
        foreach (['email', 'home_tel', 'home_address'] as $field) {
            if (array_key_exists($field, $in)) {
                $updates[$field] = trim((string)$in[$field]);
            }
        }
        if (!$updates) {
            return $this->validationError([['field' => null, 'message' => 'هیچ فیلد قابل ویرایشی ارائه نشده است']]);
        }
        if (isset($updates['email']) && $updates['email'] !== '' && !filter_var($updates['email'], FILTER_VALIDATE_EMAIL)) {
            return $this->validationError([['field' => 'email', 'message' => 'ایمیل معتبر نیست']]);
        }
        if (isset($updates['home_tel']) && mb_strlen($updates['home_tel']) > 32) {
            return $this->validationError([['field' => 'home_tel', 'message' => 'شماره تلفن بیش از حد طولانی است']]);
        }
        if (isset($updates['home_address']) && mb_strlen($updates['home_address']) > 2000) {
            return $this->validationError([['field' => 'home_address', 'message' => 'آدرس بیش از حد طولانی است']]);
        }
        if (array_key_exists('email', $updates) && $updates['email'] === '') {
            $updates['email'] = null;
        }
        $set = implode(', ', array_map(static fn(string $field): string => $field . ' = ?', array_keys($updates)));
        try {
            Database::conn()->prepare("UPDATE patients SET {$set}, updated_at = UTC_TIMESTAMP() WHERE id = ? AND deleted_at IS NULL")
                ->execute([...array_values($updates), (int)$req->user['id']]);
        } catch (\PDOException $e) {
            if ((string)$e->getCode() === '23000') {
                return $this->validationError([['field' => 'email', 'message' => 'این ایمیل قبلاً برای حساب دیگری ثبت شده است']]);
            }
            throw $e;
        }
        return $this->success(['updated' => true]);
    }

    public function appointments(Request $req): array
    {
        $patientId = (int)$req->user['id'];
        $clinicId = (int)$req->user['clinic_id'];
        $page = max(1, (int)($req->query['page'] ?? 1));
        $perPage = min(50, max(1, (int)($req->query['per_page'] ?? 20)));
        $offset = ($page - 1) * $perPage;
        $db = Database::conn();
        $count = $db->prepare('SELECT COUNT(*) FROM appointments WHERE patient_id = ? AND clinic_id = ? AND deleted_at IS NULL');
        $count->execute([$patientId, $clinicId]);
        $total = (int)$count->fetchColumn();
        $stmt = $db->prepare(
            "SELECT a.id, a.scheduled_at, a.duration_minutes, a.visit_reason, a.status,
                    u.full_name AS provider_name
             FROM appointments a
             LEFT JOIN users u ON u.id = a.provider_id
             WHERE a.patient_id = ? AND a.clinic_id = ? AND a.deleted_at IS NULL
             ORDER BY a.scheduled_at DESC LIMIT {$perPage} OFFSET {$offset}"
        );
        $stmt->execute([$patientId, $clinicId]);
        $items = array_map(static fn(array $r): array => [
            'appointment_id' => (int)$r['id'],
            'scheduled_at' => $r['scheduled_at'],
            'duration_minutes' => (int)$r['duration_minutes'],
            'reason' => $r['visit_reason'],
            'status' => $r['status'],
            'provider_name' => $r['provider_name'],
        ], $stmt->fetchAll());
        return $this->success([
            'items' => $items,
            'pagination' => [
                'total' => $total,
                'per_page' => $perPage,
                'current_page' => $page,
                'last_page' => max(1, (int)ceil($total / $perPage)),
            ],
        ]);
    }

    public function documents(Request $req): array
    {
        $stmt = Database::conn()->prepare(
            'SELECT uuid, title, type, tag, mime_type, size_bytes, url, url_expires_at, created_at
             FROM media WHERE patient_id = ? AND clinic_id = ? AND deleted_at IS NULL
             ORDER BY created_at DESC'
        );
        $stmt->execute([(int)$req->user['id'], (int)$req->user['clinic_id']]);
        $documents = array_map(static function (array $r): array {
            $bytes = (int)$r['size_bytes'];
            $size = $bytes >= 1048576 ? round($bytes / 1048576, 1) . ' MB' : ($bytes >= 1024 ? round($bytes / 1024, 1) . ' KB' : $bytes . ' B');
            return [
                'uuid' => $r['uuid'], 'title' => $r['title'], 'type' => $r['type'], 'tag' => $r['tag'],
                'mime_type' => $r['mime_type'], 'size_bytes' => $bytes, 'size_formatted' => $size,
                'url' => $r['url'], 'url_expires_at' => $r['url_expires_at'], 'created_at' => $r['created_at'],
            ];
        }, $stmt->fetchAll());
        return $this->success(['documents' => $documents]);
    }

    public function records(Request $req): array
    {
        $page = max(1, (int)($req->query['page'] ?? 1));
        $perPage = min(50, max(1, (int)($req->query['per_page'] ?? 20)));
        $offset = ($page - 1) * $perPage;
        $patientId = (int)$req->user['id'];
        $clinicId = (int)$req->user['clinic_id'];
        $db = Database::conn();
        $count = $db->prepare('SELECT COUNT(*) FROM emr_records WHERE patient_id = ? AND clinic_id = ? AND deleted_at IS NULL');
        $count->execute([$patientId, $clinicId]);
        $total = (int)$count->fetchColumn();
        $stmt = $db->prepare(
            "SELECT id, chief_complaint, diagnosis, plan, ai_accepted, created_at
             FROM emr_records WHERE patient_id = ? AND clinic_id = ? AND deleted_at IS NULL
             ORDER BY created_at DESC LIMIT {$perPage} OFFSET {$offset}"
        );
        $stmt->execute([$patientId, $clinicId]);
        return $this->success([
            'items' => $stmt->fetchAll(),
            'pagination' => [
                'total' => $total, 'per_page' => $perPage, 'current_page' => $page,
                'last_page' => max(1, (int)ceil($total / $perPage)),
            ],
        ]);
    }

    public function notificationPreferences(Request $req): array
    {
        $stmt = Database::conn()->prepare(
            'SELECT sms_appointment_reminder, sms_status_change, email_appointment_reminder, marketing_email_optin
             FROM patients WHERE id = ? AND deleted_at IS NULL LIMIT 1'
        );
        $stmt->execute([(int)$req->user['id']]);
        $row = $stmt->fetch();
        if (!$row) {
            return $this->error('بیمار یافت نشد', 404);
        }
        return $this->success([
            'sms_appointment_reminder' => (bool)$row['sms_appointment_reminder'],
            'sms_status_change' => (bool)$row['sms_status_change'],
            'email_appointment_reminder' => (bool)$row['email_appointment_reminder'],
            'email_marketing' => (bool)$row['marketing_email_optin'],
        ]);
    }

    public function updateNotificationPreferences(Request $req): array
    {
        $map = [
            'sms_appointment_reminder' => 'sms_appointment_reminder',
            'sms_status_change' => 'sms_status_change',
            'email_appointment_reminder' => 'email_appointment_reminder',
            'email_marketing' => 'marketing_email_optin',
        ];
        $updates = [];
        foreach ($map as $input => $column) {
            if (array_key_exists($input, $req->body)) {
                $updates[$column] = (bool)$req->body[$input] ? 1 : 0;
            }
        }
        if (!$updates) {
            return $this->validationError([['field' => null, 'message' => 'حداقل یک تنظیم اعلان ارسال کنید']]);
        }
        $set = implode(', ', array_map(static fn(string $field): string => $field . ' = ?', array_keys($updates)));
        Database::conn()->prepare("UPDATE patients SET {$set}, updated_at = UTC_TIMESTAMP() WHERE id = ?")
            ->execute([...array_values($updates), (int)$req->user['id']]);
        return $this->notificationPreferences($req);
    }
}
