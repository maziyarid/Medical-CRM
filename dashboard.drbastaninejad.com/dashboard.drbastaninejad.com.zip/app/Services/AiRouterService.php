<?php
declare(strict_types=1);

namespace App\Services;

/**
 * Server-only OpenRouter client for review-only clinical drafting.
 * It never persists a draft and never receives patient identifiers from the controller.
 */
final class AiRouterService
{
    private const ENDPOINT = 'https://openrouter.ai/api/v1/chat/completions';

    public function isEnabled(): bool
    {
        return (($_ENV['AI_ENABLED'] ?? '0') === '1')
            && (($_ENV['AI_ALLOW_CLINICAL_TEXT'] ?? '0') === '1')
            && $this->apiKey() !== '';
    }

    public function draftClinicalNote(string $prompt, array $context = []): string
    {
        if (!$this->isEnabled()) {
            throw new \RuntimeException('AI drafting is disabled or not fully configured.');
        }

        $prompt = trim($prompt);
        if ($prompt === '' || mb_strlen($prompt) > 2000) {
            throw new \InvalidArgumentException('AI prompt must contain 1–2000 characters.');
        }

        $contextText = $this->buildContext($context);
        $userText = "درخواست کاربر:\n" . $this->redactDirectIdentifiers($prompt);
        if ($contextText !== '') {
            $userText .= "\n\nمتن بالینی واردشده در همین فرم:\n" . $contextText;
        }

        $payload = [
            'model' => trim((string)($_ENV['OPENROUTER_MODEL'] ?? 'openai/gpt-4o-mini')),
            'messages' => [
                [
                    'role' => 'system',
                    'content' => 'شما دستیار نگارش پرونده پزشکی هستید. فقط یک پیش‌نویس کوتاه فارسی برای بازبینی پزشک تولید کنید. تشخیص قطعی، تضمین درمان یا دستور خودکار ندهید. هیچ داده‌ای را ذخیره نکنید. اگر داده کافی نیست، با صراحت بگویید نیاز به تکمیل اطلاعات و بررسی پزشک دارد.',
                ],
                ['role' => 'user', 'content' => $userText],
            ],
            'temperature' => 0.2,
            'max_tokens' => max(100, min(1200, (int)($_ENV['AI_MAX_TOKENS'] ?? 600))),
        ];

        $json = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($json === false) {
            throw new \RuntimeException('Could not encode AI request.');
        }

        [$status, $body] = $this->postJson($json);
        if ($status < 200 || $status >= 300) {
            throw new \RuntimeException('AI provider returned HTTP ' . $status . '.');
        }
        $decoded = json_decode($body, true);
        $content = trim((string)($decoded['choices'][0]['message']['content'] ?? ''));
        if ($content === '') {
            throw new \RuntimeException('AI provider returned an empty draft.');
        }
        return mb_substr($content, 0, 8000);
    }

    /** @return array{0:int,1:string} */
    private function postJson(string $json): array
    {
        $headers = [
            'Authorization: Bearer ' . $this->apiKey(),
            'Content-Type: application/json',
            'Accept: application/json',
        ];
        $siteUrl = trim((string)($_ENV['OPENROUTER_SITE_URL'] ?? 'https://dashboard.drbastaninejad.com'));
        if ($siteUrl !== '') {
            $headers[] = 'HTTP-Referer: ' . $siteUrl;
            $headers[] = 'X-OpenRouter-Title: Dr Bastaninejad Clinical Dashboard';
        }

        if (function_exists('curl_init')) {
            $ch = curl_init(self::ENDPOINT);
            if ($ch === false) {
                throw new \RuntimeException('Could not initialise HTTP client.');
            }
            curl_setopt_array($ch, [
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => $json,
                CURLOPT_HTTPHEADER => $headers,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_CONNECTTIMEOUT => 5,
                CURLOPT_TIMEOUT => 30,
            ]);
            $body = curl_exec($ch);
            $status = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
            $error = curl_error($ch);
            curl_close($ch);
            if ($body === false || $error !== '') {
                throw new \RuntimeException('AI provider network request failed.');
            }
            return [$status, (string)$body];
        }

        if (!filter_var(ini_get('allow_url_fopen'), FILTER_VALIDATE_BOOL)) {
            throw new \RuntimeException('No supported outbound HTTP transport is available.');
        }
        $context = stream_context_create(['http' => [
            'method' => 'POST',
            'header' => implode("\r\n", $headers),
            'content' => $json,
            'timeout' => 30,
            'ignore_errors' => true,
        ]]);
        $body = @file_get_contents(self::ENDPOINT, false, $context);
        if ($body === false) {
            throw new \RuntimeException('AI provider network request failed.');
        }
        $status = 0;
        foreach (($http_response_header ?? []) as $line) {
            if (preg_match('#^HTTP/\S+\s+(\d{3})#', $line, $m)) {
                $status = (int)$m[1];
                break;
            }
        }
        return [$status, $body];
    }

    private function buildContext(array $context): string
    {
        $labels = [
            'subjective' => 'Subjective',
            'objective' => 'Objective',
            'assessment' => 'Assessment',
            'plan' => 'Plan',
        ];
        $lines = [];
        foreach ($labels as $key => $label) {
            $value = trim((string)($context[$key] ?? ''));
            if ($value === '') {
                continue;
            }
            $value = mb_substr($this->redactDirectIdentifiers($value), 0, 3000);
            $lines[] = $label . ': ' . $value;
        }
        return implode("\n", $lines);
    }

    private function redactDirectIdentifiers(string $text): string
    {
        $text = preg_replace('/\b09\d{9}\b/u', '[شماره همراه حذف شد]', $text) ?? $text;
        $text = preg_replace('/\b\d{10}\b/u', '[شناسه عددی حذف شد]', $text) ?? $text;
        $text = preg_replace('/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/iu', '[ایمیل حذف شد]', $text) ?? $text;
        return $text;
    }

    private function apiKey(): string
    {
        $key = trim((string)($_ENV['OPENROUTER_API_KEY'] ?? ''));
        return str_starts_with($key, 'CHANGE_ME') ? '' : $key;
    }
}
