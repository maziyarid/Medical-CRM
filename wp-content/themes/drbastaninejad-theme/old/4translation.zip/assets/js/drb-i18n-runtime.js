/**
 * Runtime localization layer over the compiled Persian React dist6.
 * Uses window.__DRB_I18N__ (injected by theme) + a FA→key dictionary.
 * Preserves exact layout/animations; only text nodes and selected attributes change.
 */
(function () {
  'use strict';

  if (typeof window === 'undefined') return;

  var i18n = window.__DRB_I18N__ || {};
  var lang = (i18n.lang || 'fa').toLowerCase();
  var strings = i18n.strings || {};
  if (lang === 'fa' || !strings || Object.keys(strings).length === 0) {
    return; // nothing to do on Persian
  }

  // Map frequent hardcoded Persian phrases (from dist6) → pack keys or direct translation
  // Prefer pack key so one source of truth.
  var FA_TO_KEY = {
    'خانه': 'nav_home',
    'درباره': 'nav_about',
    'خدمات': 'nav_services',
    'گالری': 'nav_gallery',
    'سوالات متداول': 'nav_faq',
    'سوالات': 'nav_faq',
    'مقالات': 'nav_blog',
    'تماس': 'nav_contact',
    'رزرو نوبت': 'nav_booking',
    'ورود بیمار': 'nav_patient_login',
    'رزرو آنلاین': 'cta_book',
    'تماس با کلینیک': 'cta_contact',
    'نام و نام‌خانوادگی': 'form_name',
    'نام و نام خانوادگی': 'form_name',
    'شماره موبایل': 'form_mobile',
    'ایمیل': 'form_email',
    'نوع خدمت مورد نظر': 'form_procedure',
    'پیام یا توضیحات': 'form_message',
    'ارسال درخواست': 'form_submit',
    'رزرو مشاوره': 'booking_title',
    'سن بین ۱۸ تا ۴۵ سال': 'eligibility_age',
    'حداقل ۲۴ ماه از جراحی قبلی گذشته باشد': 'eligibility_revision',
    'نمونه‌های قبل و بعد': 'gallery_title',
    'نتایج واقعی با رضایت انتشار': 'gallery_subtitle',
    'همه نمونه‌ها': 'gallery_all',
    'جراحی اولیه': 'gallery_primary',
    'جراحی ترمیمی': 'gallery_revision',
    'صفحه پیدا نشد': '404_title',
    'سیاست حریم خصوصی': 'privacy',
    'شرایط استفاده': 'terms',
    'سیاست لغو': 'cancellation',
    'نقشه سایت': 'sitemap',
    'جراحی بینی اولیه': 'svc_rhinoplasty_primary',
    'جراحی بینی ترمیمی': 'svc_rhinoplasty_revision',
    'جراحی بینی استخوانی': 'svc_rhinoplasty_bony',
    'بینی طبیعی': 'svc_rhinoplasty_natural',
    'رفع قوز بینی': 'svc_hump_removal',
    'سپتوپلاستی': 'svc_septoplasty',
    'توربینوپلاستی': 'svc_turbinoplasty',
    'آندوسکوپی سینوس (FESS)': 'svc_sinus_endoscopy',
    'آندوسکوپی سینوس': 'svc_sinus_endoscopy',
    'جستجو در خدمات و مقالات...': 'search_placeholder',
    'در حال بارگذاری...': 'loading',
    'ادامه مطلب': 'read_more',
    'بستن': 'close',
    'تمامی حقوق محفوظ است': 'footer_rights',
    'تهران، ایران': 'footer_address',
  };

  // Direct phrase overrides (longer / unique) when key not enough
  var FA_DIRECT = {
    'دکتر شاهین باستانی‌نژاد': strings.site_name || 'Dr. Shahin Bastaninejad',
    'دکتر باستانی‌نژاد': strings.site_name || 'Dr. Bastaninejad',
    'کلینیک دکتر باستانی‌نژاد': (strings.site_name || 'Dr. Bastaninejad') + ' Clinic',
    'پذیرش فقط برای بازه سنی ۱۸ تا ۴۵ سال انجام می‌شود': strings.eligibility_age || '',
    'باید ۲۴ ماه کامل از جراحی قبلی گذشته باشد': strings.eligibility_revision || '',
    'تأیید شرایط پذیرش الزامی است': strings.form_accept_terms || '',
    'لطفاً نام خود را وارد کنید': strings.form_required || '',
    'لطفاً شماره تلفن را وارد کنید': strings.form_required || '',
    'فرمت شماره اشتباه است (مثال: 09121234567)': strings.form_invalid_phone || '',
    'لطفاً نوع خدمت را انتخاب کنید': strings.form_select_service || '',
    'درخواست شما ثبت شد ✓': strings.form_success || '',
    'پیام شما ارسال شد!': strings.form_success || '',
    'نمونه تأییدشده‌ای برای انتشار ثبت نشده است.': strings.gallery_empty || '',
    'نمونه تأییدشده‌ای برای انتشار ثبت نشده است': strings.gallery_empty || '',
    'گالری قبل و بعد در حال بازبینی است': strings.gallery_demo_notice || '',
    'نسخه نمایشی آماده تأیید پزشک': strings.gallery_demo_notice || '',
  };

  function translateText(text) {
    if (!text || typeof text !== 'string') return text;
    var t = text.trim();
    if (!t) return text;

    if (FA_DIRECT[t]) return FA_DIRECT[t];
    if (FA_TO_KEY[t] && strings[FA_TO_KEY[t]]) return strings[FA_TO_KEY[t]];

    // Partial / contains for longer mixed nodes
    var out = text;
    Object.keys(FA_DIRECT).forEach(function (fa) {
      if (out.indexOf(fa) !== -1) {
        out = out.split(fa).join(FA_DIRECT[fa]);
      }
    });
    Object.keys(FA_TO_KEY).forEach(function (fa) {
      var key = FA_TO_KEY[fa];
      if (strings[key] && out.indexOf(fa) !== -1) {
        out = out.split(fa).join(strings[key]);
      }
    });
    return out;
  }

  function walk(node) {
    if (!node) return;
    if (node.nodeType === 3) { // text
      var parent = node.parentElement;
      if (parent && parent.closest && parent.closest('script,style,noscript,code,pre')) return;
      var next = translateText(node.nodeValue);
      if (next !== node.nodeValue) node.nodeValue = next;
      return;
    }
    if (node.nodeType !== 1) return;
    // attributes that often hold UI strings
    ['placeholder', 'title', 'aria-label', 'alt'].forEach(function (attr) {
      if (node.hasAttribute && node.hasAttribute(attr)) {
        var v = node.getAttribute(attr);
        var nv = translateText(v);
        if (nv !== v) node.setAttribute(attr, nv);
      }
    });
    var child = node.firstChild;
    while (child) {
      var n = child.nextSibling;
      walk(child);
      child = n;
    }
  }

  function run() {
    var root = document.getElementById('root') || document.body;
    if (!root) return;
    walk(root);
    // also native header/footer if present
    document.querySelectorAll('.drb-native-header, .drb-native-footer, #drb-lang-bar').forEach(walk);
  }

  var scheduled = false;
  function schedule() {
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(function () {
      scheduled = false;
      run();
    });
  }

  // Initial + observe React mutations
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', schedule);
  } else {
    schedule();
  }
  setTimeout(run, 800);
  setTimeout(run, 2000);
  setTimeout(run, 4000);

  if (typeof MutationObserver !== 'undefined') {
    var obs = new MutationObserver(function () { schedule(); });
    obs.observe(document.documentElement, { childList: true, subtree: true, characterData: true });
  }
})();
