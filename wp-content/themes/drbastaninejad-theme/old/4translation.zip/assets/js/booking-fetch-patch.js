/**
 * Dr. Bastaninejad — booking fetch patch.
 *
 * Two confirmed production bugs are fixed here without rebuilding the
 * minified React bundle:
 *
 *  (A) "Cannot read properties of undefined (reading 'appointment')"
 *      The bundle reads window.__DRB_FORMS_API__.appointment at submit time
 *      while evaluating the fetch argument. If the bootstrap inline script never
 *      ran (e.g. a native-template page where the main bundle is not enqueued,
 *      or a partial upload), the global is undefined and the submit handler
 *      throws BEFORE fetch is called — so this fetch wrapper cannot prevent it.
 *      The real guard is the PHP-side drb_ensure_forms_api_bootstrap() in
 *      inc/react-app.php, which guarantees the global exists on every page.
 *      This file's responsibility for bug A is limited to logging a clear warning
 *      when the global is missing, so a rejected request is diagnosable.
 *
 *  (B) Booking submit is rejected with 403 "نشست فرم منقضی شده است"
 *      The bundle sends only `Content-Type` and never the X-DRB-Form-Nonce
 *      header that inc/forms.php verifies with wp_verify_nonce(). We wrap
 *      window.fetch so every POST to our own REST endpoints
 *      (/wp-json/drb/v1/appointment and /contact) gets the nonce header
 *      attached automatically.
 *
 * Scope: only requests whose URL matches our REST endpoints are modified.
 * Every other fetch on the page is left untouched.
 */
(function () {
  'use strict';

  if (window.__DRB_FETCH_PATCHED__) {
    return;
  }
  window.__DRB_FETCH_PATCHED__ = true;

  var NONCE_HEADER = 'X-DRB-Form-Nonce';

  /** Get the forms API object if it is safe to use. */
  function getApi() {
    var api = window.__DRB_FORMS_API__;
    if (!api || typeof api !== 'object') {
      return null;
    }
    return api;
  }

  /** True when a request URL targets our own public form REST endpoints. */
  function isOurEndpoint(url) {
    if (!url) {
      return false;
    }
    var str = String(url);

    // 1) Compare against the configured endpoints first. rest_url() may emit an
    //    absolute URL, a pretty permalink, or a query-string form
    //    (?rest_route=/drb/v1/...). Matching the exact configured endpoint
    //    strings is the most reliable signal that this is our own request.
    var api = getApi();
    if (api) {
      var appt = api.appointment;
      var contact = api.contact;
      if (appt && str.indexOf(appt) !== -1) {
        return true;
      }
      if (contact && str.indexOf(contact) !== -1) {
        return true;
      }
    }

    // 2) Fallback regex for same-origin relative URLs and any absolute URL that
    //    hits the /wp-json/drb/v1/ namespace.
    if (/\/wp-json\/drb\/v1\/(appointment|contact)(?:[/?#]|$)/i.test(str)) {
      return true;
    }

    // 3) Query-string REST routing: ?rest_route=/drb/v1/(appointment|contact)
    if (/rest_route=[^&]*\/drb\/v1\/(appointment|contact)(?:[/?#]|$)/i.test(str)) {
      return true;
    }

    return false;
  }

  /** Show a clear Persian error in the console for ops triage. */
  function warn(message) {
    if (window.console && typeof console.warn === 'function') {
      console.warn('[DRB booking] ' + message);
    }
  }

  var originalFetch = window.fetch;
  if (typeof originalFetch !== 'function') {
    warn('window.fetch is unavailable; cannot patch booking requests.');
    return;
  }

  window.fetch = function patchedFetch(input, init) {
    try {
      var url = typeof input === 'string' ? input : (input && input.url) ? input.url : '';
      if (isOurEndpoint(url)) {
        init = init || {};
        if (typeof init === 'object' && init !== null) {
          init.headers = init.headers || {};
          // Headers may be a plain object, an array of pairs, or a Headers instance.
          if (init.headers instanceof Headers) {
            if (!init.headers.has(NONCE_HEADER)) {
              var api0 = getApi();
              if (api0 && api0.nonce) {
                init.headers.set(NONCE_HEADER, api0.nonce);
              } else {
                warn('forms API global missing; request will be rejected by the server.');
              }
            }
          } else if (Array.isArray(init.headers)) {
            var hasNonce = init.headers.some(function (pair) {
              return pair && pair[0] && pair[0].toLowerCase() === NONCE_HEADER.toLowerCase();
            });
            if (!hasNonce) {
              var api1 = getApi();
              if (api1 && api1.nonce) {
                init.headers.push([NONCE_HEADER, api1.nonce]);
              } else {
                warn('forms API global missing; request will be rejected by the server.');
              }
            }
          } else {
            var lowered = {};
            var keys = Object.keys(init.headers);
            for (var i = 0; i < keys.length; i++) {
              lowered[keys[i].toLowerCase()] = true;
            }
            if (!lowered[NONCE_HEADER.toLowerCase()]) {
              var api2 = getApi();
              if (api2 && api2.nonce) {
                init.headers[NONCE_HEADER] = api2.nonce;
              } else {
                warn('forms API global missing; request will be rejected by the server.');
              }
            }
          }
        }
      }
    } catch (patchError) {
      warn('fetch patch error: ' + (patchError && patchError.message ? patchError.message : String(patchError)));
    }
    return originalFetch.call(window, input, init);
  };

  // Preserve a backdoor in case a future bundle ships its own nonce handling.
  window.__DRB_FETCH_ORIGINAL__ = originalFetch;
})();
