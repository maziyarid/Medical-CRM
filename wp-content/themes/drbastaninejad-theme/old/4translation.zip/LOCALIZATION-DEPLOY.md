# Localization 4.3.5 deployment

1. Back up the current theme and WordPress database.
2. **Remove the earlier MU bridge completely** before uploading this theme:
   - `wp-content/mu-plugins/drb-localization.php`
   - `wp-content/mu-plugins/drb-localization/`
   The theme now owns localization. Leaving the bridge active duplicates canonical/hreflang output.
3. Upload this complete theme over `wp-content/themes/drbastaninejad-theme/`.
4. Do not import the supplied WordPress XML; it was used only to map the current live page IDs/slugs.
5. Purge WordPress, LiteSpeed/server, object and CDN caches.
6. Open the main Persian site first and confirm it still uses the existing React design.
7. Test `https://en.drbastaninejad.com/`, `/about/`, `/booking/`, `/faq/`; then Arabic and one other language.

Non-Persian language hosts use the theme-native localized renderer because the supplied compiled React bundle contains hundreds of hardcoded Persian strings and has no source/i18n build path. Persian remains on the existing React renderer. Booking/contact still post to the existing REST routes with the existing nonce and clinical bridge.

Expected source on English home: one Rank Math canonical, one set of hreflang links, English title/description/Open Graph/WebPage schema, `lang="en"`, `dir="ltr"`, and no Persian page body.
