<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<header class="drb-native-header" role="banner">
  <div class="drb-native-header__inner">
    <a class="drb-native-header__brand" href="<?php echo esc_url( home_url( '/' ) ); ?>">
      <?php echo esc_html( function_exists( '__t' ) ? __t( 'site_name' ) : get_bloginfo( 'name' ) ); ?>
    </a>
    <nav class="drb-native-header__nav" aria-label="<?php echo esc_attr( function_exists( '__t' ) ? __t( 'nav_primary_label' ) : 'ناوبری اصلی' ); ?>">
      <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php echo esc_html( function_exists( '__t' ) ? __t( 'nav_home' ) : 'خانه' ); ?></a>
      <a href="<?php echo esc_url( home_url( '/about/' ) ); ?>"><?php echo esc_html( function_exists( '__t' ) ? __t( 'nav_about' ) : 'درباره' ); ?></a>
      <a href="<?php echo esc_url( home_url( '/services/' ) ); ?>"><?php echo esc_html( function_exists( '__t' ) ? __t( 'nav_services' ) : 'خدمات' ); ?></a>
      <a href="<?php echo esc_url( home_url( '/gallery/' ) ); ?>"><?php echo esc_html( function_exists( '__t' ) ? __t( 'nav_gallery' ) : 'گالری' ); ?></a>
      <a href="<?php echo esc_url( home_url( '/faq/' ) ); ?>"><?php echo esc_html( function_exists( '__t' ) ? __t( 'nav_faq' ) : 'سوالات' ); ?></a>
      <a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>"><?php echo esc_html( function_exists( '__t' ) ? __t( 'nav_contact' ) : 'تماس' ); ?></a>
      <a class="drb-native-header__booking" href="<?php echo esc_url( home_url( '/booking/' ) ); ?>"><?php echo esc_html( function_exists( '__t' ) ? __t( 'nav_booking' ) : 'رزرو نوبت' ); ?></a>
      <?php if ( function_exists( 'drb_language_dropdown_html' ) ) : ?>
        <span class="drb-native-header__lang"><?php echo drb_language_dropdown_html(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
        <?php do_action( 'drb_native_header_lang_rendered' ); ?>
      <?php endif; ?>
    </nav>
  </div>
</header>
