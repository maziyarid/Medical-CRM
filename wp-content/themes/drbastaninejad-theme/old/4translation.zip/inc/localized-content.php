<?php
/** Theme-native localized page/content layer for non-Persian language hosts. */
defined( 'ABSPATH' ) || exit;

function drb_content_pack( $lang = null ) {
    static $cache = array();
    $lang = $lang ?: drb_detect_lang();
    if ( isset( $cache[ $lang ] ) ) return $cache[ $lang ];
    $file = DRB_THEME_DIR . '/languages/content/pack_' . sanitize_key( $lang ) . '.json';
    if ( ! is_readable( $file ) ) return $cache[ $lang ] = array();
    $data = json_decode( (string) file_get_contents( $file ), true );
    return $cache[ $lang ] = is_array( $data ) ? $data : array();
}

function drb_localized_page_map() {
    return array(
        'home' => array( 'id' => 53, 'fa_path' => '/' ),
        'about' => array( 'id' => 35, 'fa_path' => '/about/' ),
        'contact' => array( 'id' => 36, 'fa_path' => '/contact/' ),
        'booking' => array( 'id' => 39, 'fa_path' => '/booking/' ),
        'faq' => array( 'id' => 38, 'fa_path' => '/سوالات-متداول/' ),
        'gallery' => array( 'id' => 40, 'fa_path' => '/gallery/' ),
        'after-splint-care' => array( 'id' => 52, 'fa_path' => '/atl-removal/' ),
        'privacy' => array( 'id' => 3, 'fa_path' => '/سیاست-حفظ-حریم-خصوصی/' ),
        'articles' => array( 'id' => 34, 'fa_path' => '/blog/' ),
        'dr-shahin-bastaninejad' => array( 'id' => 37, 'fa_path' => '/دکتر-شاهین-باستانی-نژاد/' ),
    );
}

function drb_localized_key_from_source_slug( $source ) {
    $aliases = array(
        'صفحه-اصلی' => 'home', 'درباره-دکتر-شاهین-باستانی-نژاد' => 'about',
        'تماس-با-ما' => 'contact', 'دریافت-نوبت' => 'booking', 'سوالات-متداول' => 'faq',
        'گالری' => 'gallery', 'آتل-بینی' => 'after-splint-care',
        'سیاست-حفظ-حریم-خصوصی' => 'privacy', 'مقالات' => 'articles',
        'دکتر-شاهین-باستانی-نژاد' => 'dr-shahin-bastaninejad',
    );
    return $aliases[ $source ] ?? '';
}

function drb_localized_page( $key = null, $lang = null ) {
    $lang = $lang ?: drb_detect_lang();
    if ( 'fa' === $lang ) return array();
    $key = $key ?: drb_current_localized_key();
    foreach ( (array) ( drb_content_pack( $lang )['pages'] ?? array() ) as $page ) {
        $candidate = drb_localized_key_from_source_slug( (string) ( $page['source_slug_fa'] ?? '' ) );
        if ( $candidate === $key ) return $page;
    }
    return array();
}

function drb_current_localized_key() {
    if ( ! empty( $GLOBALS['drb_localized_forced_key'] ) ) return (string) $GLOBALS['drb_localized_forced_key'];
    $id = get_queried_object_id();
    foreach ( drb_localized_page_map() as $key => $row ) if ( (int) $row['id'] === (int) $id ) return $key;
    $slug = $id ? urldecode( (string) get_post_field( 'post_name', $id ) ) : '';
    $live = array( 'home'=>'home', 'about'=>'about', 'contact'=>'contact', 'booking'=>'booking', 'gallery'=>'gallery', 'atl-removal'=>'after-splint-care', 'blog'=>'articles' );
    return $live[ $slug ] ?? 'home';
}

function drb_localized_host( $lang ) {
    return 'fa' === $lang ? 'https://drbastaninejad.com' : 'https://' . $lang . '.drbastaninejad.com';
}

function drb_localized_path( $key, $lang = null ) {
    $lang = $lang ?: drb_detect_lang();
    $map = drb_localized_page_map();
    if ( 'fa' === $lang ) return $map[ $key ]['fa_path'] ?? '/';
    $page = drb_localized_page( $key, $lang );
    if ( 'home' === $key ) return '/';
    return ! empty( $page['slug'] ) ? '/' . trim( (string) $page['slug'], '/' ) . '/' : '/';
}

function drb_localized_url( $key, $lang = null ) {
    $lang = $lang ?: drb_detect_lang();
    return drb_localized_host( $lang ) . drb_localized_path( $key, $lang );
}

function drb_nav_url( $key ) {
    return drb_localized_url( $key, drb_detect_lang() );
}

function drb_localized_url_for_post( $post_id, $lang ) {
    if ( ! empty( $GLOBALS['drb_localized_forced_key'] ) ) return drb_localized_url( (string) $GLOBALS['drb_localized_forced_key'], $lang );
    foreach ( drb_localized_page_map() as $key => $row ) if ( (int) $row['id'] === (int) $post_id ) return drb_localized_url( $key, $lang );
    return '';
}

/* Resolve translated slugs to the real source page without creating duplicate DB rows. */
add_filter( 'request', function ( $vars ) {
    if ( is_admin() || 'fa' === drb_detect_lang() ) return $vars;
    $path = trim( (string) parse_url( (string) ( $_SERVER['REQUEST_URI'] ?? '/' ), PHP_URL_PATH ), '/' );
    if ( '' === $path ) { $GLOBALS['drb_localized_forced_key'] = 'home'; return $vars; }
    foreach ( drb_localized_page_map() as $key => $row ) {
        $wanted = trim( drb_localized_path( $key ), '/' );
        if ( $wanted && rawurldecode( $path ) === rawurldecode( $wanted ) ) {
            $GLOBALS['drb_localized_forced_key'] = $key;
            $source_id = get_post_status( $row['id'] ) === 'publish' ? (int) $row['id'] : 53;
            return array( 'page_id' => $source_id );
        }
    }
    return $vars;
}, 1 );

function drb_localized_collection( $name, $lang = null ) {
    $pack = drb_content_pack( $lang ?: drb_detect_lang() );
    $value = $pack[ $name ] ?? array();
    return is_array( $value ) ? $value : array();
}

function drb_localized_forms_map() { return drb_localized_collection( 'forms' ); }
function drb_form_t( $source, $fallback = '' ) {
    $map = drb_localized_forms_map();
    if ( isset( $map[ $source ] ) && '' !== $map[ $source ] ) return (string) $map[ $source ];
    return '' !== $fallback ? (string) $fallback : (string) $source;
}
function drb_localized_content_html( $html ) {
    $keys = array( 'about', 'booking', 'contact', 'gallery' );
    foreach ( $keys as $key ) $html = str_replace( 'href="/' . $key . '/"', 'href="' . esc_url( drb_nav_url( $key ) ) . '"', (string) $html );
    return $html;
}

/* Rank Math and social metadata must describe the localized virtual page. */
add_filter( 'rank_math/frontend/title', function ( $title ) {
    $page = drb_localized_page(); return $page['seo_title'] ?? $title;
}, 30 );
add_filter( 'rank_math/frontend/description', function ( $description ) {
    $page = drb_localized_page(); return $page['seo_description'] ?? $description;
}, 30 );
add_filter( 'rank_math/frontend/canonical', function ( $canonical ) {
    return 'fa' === drb_detect_lang() ? $canonical : drb_localized_url( drb_current_localized_key() );
}, 30 );
foreach ( array( 'facebook', 'twitter' ) as $network ) {
    add_filter( 'rank_math/opengraph/' . $network . '/title', function ( $title ) { $p = drb_localized_page(); return $p['seo_title'] ?? $title; }, 30 );
    add_filter( 'rank_math/opengraph/' . $network . '/description', function ( $description ) { $p = drb_localized_page(); return $p['seo_description'] ?? $description; }, 30 );
}
add_filter( 'rank_math/opengraph/facebook/url', function ( $url ) {
    return 'fa' === drb_detect_lang() ? $url : drb_localized_url( drb_current_localized_key() );
}, 30 );
add_filter( 'rank_math/opengraph/facebook/site_name', function ( $name ) { return 'fa' === drb_detect_lang() ? $name : __t( 'site_name' ); }, 30 );
add_filter( 'rank_math/json_ld', function ( $data ) {
    if ( 'fa' === drb_detect_lang() ) return $data;
    $page = drb_localized_page(); $url = drb_localized_url( drb_current_localized_key() ); $lang = drb_html_lang();
    foreach ( $data as &$node ) {
        if ( ! is_array( $node ) ) continue;
        $types = (array) ( $node['@type'] ?? array() );
        if ( in_array( 'WebPage', $types, true ) ) {
            $node['@id'] = $url . '#webpage'; $node['name'] = $page['seo_title'] ?? $page['title'] ?? ''; $node['description'] = $page['seo_description'] ?? ''; $node['url'] = $url; $node['inLanguage'] = $lang;
            if ( isset( $node['isPartOf']['@id'] ) ) $node['isPartOf']['@id'] = drb_localized_host( drb_detect_lang() ) . '/#website';
            if ( isset( $node['about']['@id'] ) ) $node['about']['@id'] = drb_localized_host( drb_detect_lang() ) . '/#person';
        }
        if ( in_array( 'WebSite', $types, true ) ) { $node['@id'] = drb_localized_host( drb_detect_lang() ) . '/#website'; $node['name'] = __t( 'site_name' ); $node['url'] = drb_localized_host( drb_detect_lang() ); $node['inLanguage'] = $lang; unset( $node['potentialAction'] ); }
        if ( in_array( 'Organization', $types, true ) || in_array( 'Person', $types, true ) ) { $node['@id'] = drb_localized_host( drb_detect_lang() ) . '/#person'; $node['name'] = __t( 'site_name' ); $node['url'] = drb_localized_host( drb_detect_lang() ); }
    }
    unset( $node ); return $data;
}, 30 );

/* Avoid main-domain feeds/oEmbed metadata on virtual localized pages. */
add_action( 'wp', function () {
    if ( 'fa' === drb_detect_lang() ) return;
    remove_action( 'wp_head', 'feed_links', 2 ); remove_action( 'wp_head', 'feed_links_extra', 3 );
    remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
} );

add_action( 'wp_enqueue_scripts', function () {
    if ( 'fa' === drb_detect_lang() ) return;
    $file = DRB_THEME_DIR . '/assets/js/localized-forms.js';
    if ( is_readable( $file ) ) wp_enqueue_script( 'drb-localized-forms', DRB_THEME_URI . '/assets/js/localized-forms.js', array(), filemtime( $file ), true );
}, 40 );
