<?php
defined( 'ABSPATH' ) || exit;

function drb_source_files() {
    return array(
        'content' => DRB_THEME_DIR . '/demo-content/wxr-content.json',
        'faqs' => DRB_THEME_DIR . '/demo-content/wxr-faqs.json',
        'services' => DRB_THEME_DIR . '/demo-content/dist6-services.json',
        'cases' => DRB_THEME_DIR . '/demo-content/case-galleries.json',
        'manifest' => DRB_THEME_DIR . '/demo-content/source-manifest.json',
    );
}

function drb_source_json( $key ) {
    $files = drb_source_files();
    if ( empty( $files[ $key ] ) || ! is_readable( $files[ $key ] ) ) return array();
    $value = json_decode( file_get_contents( $files[ $key ] ), true );
    return is_array( $value ) ? $value : array();
}

function drb_register_source_import_page() {
    add_theme_page( 'درون‌ریزی منبع اصلی', 'درون‌ریزی منبع اصلی', 'manage_options', 'drb-source-import', 'drb_render_source_import_page' );
}
add_action( 'admin_menu', 'drb_register_source_import_page' );

function drb_source_status() {
    $manifest = drb_source_json( 'manifest' );
    $attachment_counts = wp_count_posts( 'attachment' );
    return array(
        'manifest' => $manifest,
        'posts' => (int) wp_count_posts( 'post' )->publish,
        'pages' => (int) wp_count_posts( 'page' )->publish,
        'faqs' => (int) wp_count_posts( 'clinic_faq' )->publish,
        'media' => isset( $attachment_counts->inherit ) ? (int) $attachment_counts->inherit : 0,
        'imported_at' => get_option( 'drb_source_imported_at', '' ),
        'source_hash' => get_option( 'drb_source_hash', '' ),
    );
}

function drb_render_source_import_page() {
    if ( ! current_user_can( 'manage_options' ) ) return;
    $s = drb_source_status(); $m = $s['manifest'];
    ?>
    <div class="wrap drb-admin" dir="rtl">
        <h1>درون‌ریزی منبع اصلی سایت</h1>
        <p>منبع محتوا فایل رسمی WordPress.2026-07-09.xml است. محتوای موجود بازنویسی نمی‌شود؛ فقط رکوردهای مفقود و رسانه‌های بسته اضافه می‌شوند.</p>
        <?php if ( isset( $_GET['drb_imported'] ) ) : ?><div class="notice notice-success"><p>درون‌ریزی منبع و ثبت دارایی‌ها تکمیل شد.</p></div><?php endif; ?>
        <div class="drb-source-grid">
            <div><strong>نوشته منبع</strong><span><?php echo esc_html( $m['importable_posts'] ?? 0 ); ?></span></div>
            <div><strong>صفحه منبع</strong><span><?php echo esc_html( $m['importable_pages'] ?? 0 ); ?></span></div>
            <div><strong>FAQ اصلی</strong><span><?php echo esc_html( $m['faq_count'] ?? 0 ); ?></span></div>
            <div><strong>رکورد رسانه WXR</strong><span><?php echo esc_html( $m['attachment_records'] ?? 0 ); ?></span></div>
            <div><strong>گالری نمونه</strong><span><?php echo esc_html( $m['demo_case_galleries'] ?? 0 ); ?></span></div>
            <div><strong>تصویر نمونه WebP</strong><span><?php echo esc_html( $m['demo_case_images'] ?? 0 ); ?></span></div>
        </div>
        <p><strong>آخرین اجرا:</strong> <?php echo $s['imported_at'] ? esc_html( $s['imported_at'] ) : 'هنوز اجرا نشده'; ?></p>
        <div class="notice notice-info inline"><p>گالری قدیمی وارد نمی‌شود. چهارده گالری نمونه این بسته با نام عمومی ناشناس، ۷۰ تصویر WebP و ساختار چندنما به‌صورت جداگانه وارد می‌شوند.</p></div>
        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
            <input type="hidden" name="action" value="drb_import_source">
            <?php wp_nonce_field( 'drb_import_source', 'drb_source_nonce' ); submit_button( 'درون‌ریزی و همگام‌سازی موارد مفقود' ); ?>
        </form>
    </div><?php
}

function drb_handle_source_import() {
    if ( ! current_user_can( 'manage_options' ) ) wp_die( 'دسترسی مجاز نیست.' );
    check_admin_referer( 'drb_import_source', 'drb_source_nonce' );
    $id_map = array(); $page_map = array();
    foreach ( drb_source_json( 'content' ) as $record ) {
        if ( 'publish' !== ( $record['status'] ?? '' ) || ! in_array( $record['type'] ?? '', array( 'post', 'page' ), true ) ) continue;
        if ( preg_match( '/(?:بینی(?:‌|\s)*(?:گوشتی|فانتزی|عروسکی)|گوشتی|fleshy|fantasy)/iu', ( $record['title'] ?? '' ) . ' ' . ( $record['slug'] ?? '' ) ) ) continue;
        $type = $record['type']; $slug = 'page' === $type ? drb_current_design_slug( $record['title'], $record['slug'] ) : sanitize_title( $record['slug'] ?: $record['title'] );
        $existing = get_page_by_path( $slug, OBJECT, $type );
        if ( $existing ) { $id_map[ (int) $record['source_id'] ] = $existing->ID; if ( 'page' === $type ) $page_map[ $slug ] = $existing->ID; continue; }
        $postarr = array(
            'post_type' => $type, 'post_status' => 'publish', 'post_title' => wp_strip_all_tags( $record['title'] ), 'post_name' => $slug,
            'post_excerpt' => wp_kses_post( $record['excerpt'] ), 'post_content' => drb_clean_source_content( $record['content'] ),
            'post_date' => sanitize_text_field( $record['date'] ), 'post_date_gmt' => sanitize_text_field( $record['date_gmt'] ),
        );
        $id = wp_insert_post( wp_slash( $postarr ) );
        if ( ! $id || is_wp_error( $id ) ) continue;
        $id_map[ (int) $record['source_id'] ] = $id; if ( 'page' === $type ) $page_map[ $slug ] = $id;
        foreach ( (array) ( $record['categories'] ?? array() ) as $term ) drb_assign_source_term( $id, $term, 'category' );
        foreach ( (array) ( $record['tags'] ?? array() ) as $term ) drb_assign_source_term( $id, $term, 'post_tag' );
        foreach ( (array) ( $record['seo'] ?? array() ) as $key => $value ) update_post_meta( $id, sanitize_key( $key ), sanitize_textarea_field( $value ) );
        update_post_meta( $id, '_drb_source_id', (int) $record['source_id'] );
        update_post_meta( $id, '_drb_source_name', 'WordPress.2026-07-09.xml' );
        if ( ! empty( $record['patient_media_omitted'] ) ) update_post_meta( $id, '_drb_patient_media_omitted', 1 );
    }
    foreach ( drb_source_json( 'faqs' ) as $index => $faq ) {
        if ( preg_match( '/(?:بینی(?:‌|\s)*(?:گوشتی|فانتزی|عروسکی)|گوشتی|fleshy|fantasy)/iu', ( $faq['question'] ?? '' ) ) ) continue;
        $source_key = sanitize_text_field( $faq['source_id'] ?? '' );
        $found = get_posts( array( 'post_type' => 'clinic_faq', 'post_status' => 'any', 'posts_per_page' => 1, 'meta_key' => '_drb_source_id', 'meta_value' => $source_key ) );
        if ( $found ) continue;
        $id = wp_insert_post( wp_slash( array( 'post_type' => 'clinic_faq', 'post_status' => 'publish', 'post_title' => wp_strip_all_tags( $faq['question'] ), 'post_content' => wp_kses_post( $faq['answer_html'] ), 'menu_order' => $index ) ) );
        if ( $id && ! is_wp_error( $id ) ) { update_post_meta( $id, '_drb_source_id', $source_key ); update_post_meta( $id, '_drb_faq_category', sanitize_text_field( $faq['category'] ) ); }
    }
    drb_import_dist6_structured_content();
    $media = drb_import_dist6_media();
    drb_create_certificate_records( $media );
    drb_assign_post_featured_images( $media );
    drb_install_branding( $media );
    drb_create_source_menu( $page_map );
    // Re-apply the latest approved clinical copy after any historical source import.
    delete_option( 'drb_content_policy_version' );
    drb_apply_content_policy_migration();
    drb_import_demo_case_galleries();
    update_option( 'drb_source_imported_at', current_time( 'mysql' ) );
    update_option( 'drb_source_hash', hash_file( 'sha256', drb_source_files()['content'] ) );
    flush_rewrite_rules();
    wp_safe_redirect( add_query_arg( 'drb_imported', '1', admin_url( 'themes.php?page=drb-source-import' ) ) ); exit;
}
add_action( 'admin_post_drb_import_source', 'drb_handle_source_import' );

function drb_current_design_slug( $title, $fallback ) {
    $map = array( 'صفحه اصلی' => 'home', 'درباره دکتر' => 'about', 'تماس با ما' => 'contact', 'سوالات متداول' => 'faq', 'دریافت نوبت' => 'booking', 'گالری' => 'gallery', 'مقالات' => 'blog', 'نکات مهم پس از برداشتن آتل بینی' => 'atl-removal' );
    return isset( $map[ $title ] ) ? $map[ $title ] : sanitize_title( $fallback ?: $title );
}

function drb_clean_source_content( $html ) {
    $html = preg_replace( '#<(script|style|iframe|object|embed|form)[^>]*>.*?</\\1>#is', '', (string) $html );
    $html = preg_replace( '#<img[^>]+(?:before|after|gallery|قبل|بعد)[^>]*>#iu', '', $html );
    $html = preg_replace( '#https?://[^\"\'\s>]+(?:before|after|gallery|قبل|بعد)[^\"\'\s<]*#iu', '', $html );
    return wp_kses_post( drb_policy_strip_unsafe_content( $html ) );
}

function drb_assign_source_term( $post_id, $record, $taxonomy ) {
    $name = sanitize_text_field( $record['name'] ?? '' ); if ( ! $name ) return;
    $term = term_exists( $name, $taxonomy ); if ( ! $term ) $term = wp_insert_term( $name, $taxonomy, array( 'slug' => sanitize_title( $record['slug'] ?? $name ) ) );
    if ( ! is_wp_error( $term ) ) wp_set_object_terms( $post_id, array( (int) ( is_array( $term ) ? $term['term_id'] : $term ) ), $taxonomy, true );
}

function drb_dist6_media_files() {
    $base = DRB_THEME_DIR . '/assets/dist6/images'; $files = array();
    if ( ! is_dir( $base ) ) return $files;
    $iterator = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $base, FilesystemIterator::SKIP_DOTS ) );
    foreach ( $iterator as $file ) {
        if ( ! $file->isFile() || ! preg_match( '/\.(?:jpe?g|png|webp)$/i', $file->getFilename() ) ) continue;
        if ( false !== stripos( $file->getPathname(), 'Before-After' ) || false !== stripos( $file->getPathname(), 'Case-Gallery' ) || false !== stripos( $file->getPathname(), '/Blog/' ) ) continue;
        $files[] = $file->getPathname();
    }
    $files[] = DRB_THEME_DIR . '/assets/dist6/logo.png'; $files[] = DRB_THEME_DIR . '/assets/dist6/favicon-512.png';
    return array_values( array_unique( array_filter( $files, 'is_readable' ) ) );
}

function drb_import_dist6_media() {
    require_once ABSPATH . 'wp-admin/includes/image.php'; $map = array();
    foreach ( drb_dist6_media_files() as $source ) {
        $relative = ltrim( str_replace( DRB_THEME_DIR . '/assets/dist6/', '', $source ), '/' );
        $found = get_posts( array( 'post_type' => 'attachment', 'post_status' => 'inherit', 'posts_per_page' => 1, 'fields' => 'ids', 'meta_key' => '_drb_dist6_source', 'meta_value' => $relative ) );
        if ( $found ) { $map[ $relative ] = (int) $found[0]; continue; }
        $upload = wp_upload_bits( sanitize_file_name( basename( $source ) ), null, file_get_contents( $source ) ); if ( $upload['error'] ) continue;
        $mime = wp_check_filetype( $upload['file'] ); $title = pathinfo( basename( $source ), PATHINFO_FILENAME );
        $id = wp_insert_attachment( array( 'post_mime_type' => $mime['type'], 'post_title' => $title, 'post_status' => 'inherit' ), $upload['file'] );
        if ( ! $id || is_wp_error( $id ) ) continue;
        wp_update_attachment_metadata( $id, wp_generate_attachment_metadata( $id, $upload['file'] ) );
        update_post_meta( $id, '_wp_attachment_image_alt', $title ); update_post_meta( $id, '_drb_dist6_source', $relative ); $map[ $relative ] = $id;
    }
    return $map;
}

function drb_import_demo_case_galleries() {
    $cases = drb_source_json( 'cases' );
    if ( ! $cases ) return;
    require_once ABSPATH . 'wp-admin/includes/image.php';
    foreach ( $cases as $order => $case ) {
        $key = sanitize_key( $case['key'] ?? '' );
        if ( ! $key ) continue;
        $existing = get_posts( array( 'post_type' => 'case_study', 'post_status' => 'any', 'posts_per_page' => 1, 'fields' => 'ids', 'meta_key' => '_drb_demo_case_key', 'meta_value' => $key ) );
        if ( $existing ) continue;
        $case_id = wp_insert_post( array(
            'post_type' => 'case_study', 'post_status' => 'draft',
            'post_title' => sanitize_text_field( $case['label'] ?? $key ),
            'post_name' => $key, 'menu_order' => (int) $order,
        ) );
        if ( ! $case_id || is_wp_error( $case_id ) ) continue;
        $gallery = array();
        foreach ( (array) ( $case['images'] ?? array() ) as $image_index => $image ) {
            $relative = ltrim( (string) ( $image['file'] ?? '' ), '/' );
            $source = DRB_THEME_DIR . '/assets/dist6/images/Case-Gallery/' . $relative;
            if ( ! $relative || ! is_readable( $source ) ) continue;
            $source_key = 'images/Case-Gallery/' . $relative;
            $found = get_posts( array( 'post_type' => 'attachment', 'post_status' => 'inherit', 'posts_per_page' => 1, 'fields' => 'ids', 'meta_key' => '_drb_case_demo_source', 'meta_value' => $source_key ) );
            $attachment_id = $found ? (int) $found[0] : 0;
            $label = sanitize_text_field( $image['label'] ?? ( 'نمای ' . ( $image_index + 1 ) ) );
            if ( ! $attachment_id ) {
                $filename = sanitize_file_name( $key . '-' . basename( $source ) );
                $upload = wp_upload_bits( $filename, null, file_get_contents( $source ) );
                if ( $upload['error'] ) continue;
                $mime = wp_check_filetype( $upload['file'] );
                $public_title = sanitize_text_field( ( $case['label'] ?? $key ) . ' — ' . $label );
                $attachment_id = wp_insert_attachment( array( 'post_mime_type' => $mime['type'], 'post_title' => $public_title, 'post_excerpt' => $label, 'post_status' => 'inherit' ), $upload['file'], $case_id );
                if ( ! $attachment_id || is_wp_error( $attachment_id ) ) continue;
                wp_update_attachment_metadata( $attachment_id, wp_generate_attachment_metadata( $attachment_id, $upload['file'] ) );
                update_post_meta( $attachment_id, '_wp_attachment_image_alt', $public_title . '، قبل و بعد' );
                update_post_meta( $attachment_id, '_drb_case_demo_source', $source_key );
                update_post_meta( $attachment_id, '_drb_dist6_source', $source_key );
                delete_post_meta( $attachment_id, '_drb_gallery_quarantined' );
            }
            $gallery[] = array( 'id' => $attachment_id, 'label' => $label, 'interval' => sanitize_text_field( $image['interval'] ?? '' ) );
        }
        if ( ! $gallery ) { wp_delete_post( $case_id, true ); continue; }
        update_post_meta( $case_id, '_drb_demo_case_key', $key );
        update_post_meta( $case_id, '_drb_case_label', sanitize_text_field( $case['label'] ?? $key ) );
        update_post_meta( $case_id, '_drb_case_procedure', sanitize_text_field( $case['procedure'] ?? '' ) );
        update_post_meta( $case_id, '_drb_case_interval', sanitize_text_field( $case['interval'] ?? '' ) );
        update_post_meta( $case_id, '_drb_case_gallery', wp_json_encode( $gallery ) );
        update_post_meta( $case_id, '_drb_consent_reference', 'DEMO-CONSENT-USER-DECLARED' );
        update_post_meta( $case_id, '_drb_consent_verified', 1 );
        set_post_thumbnail( $case_id, $gallery[0]['id'] );
        wp_update_post( array( 'ID' => $case_id, 'post_status' => 'publish' ) );
    }
    $options = drb_get_theme_options();
    $options['gallery_enabled'] = 1;
    update_option( 'drb_theme_options', $options );
}

function drb_install_branding( $map ) {
    if ( ! empty( $map['logo.png'] ) ) set_theme_mod( 'custom_logo', $map['logo.png'] );
    if ( ! empty( $map['favicon-512.png'] ) ) update_option( 'site_icon', $map['favicon-512.png'] );
}

function drb_import_dist6_structured_content() {
    $services = drb_source_json( 'services' );
    foreach ( $services as $index => $item ) {
        if ( preg_match( '/(?:گوشتی|فانتزی|عروسکی|fleshy|fantasy)/iu', ( $item['title'] ?? '' ) . ' ' . ( $item['slug'] ?? '' ) ) ) continue;
        if ( get_page_by_path( $item['slug'], OBJECT, 'service' ) ) continue;
        $id = wp_insert_post( array( 'post_type' => 'service', 'post_status' => 'publish', 'post_name' => sanitize_title( $item['slug'] ), 'post_title' => wp_strip_all_tags( $item['title'] ), 'post_excerpt' => sanitize_textarea_field( $item['description'] ), 'post_content' => '<p>' . esc_html( $item['description'] ) . '</p>', 'menu_order' => $index ) );
        if ( $id && ! is_wp_error( $id ) ) { update_post_meta( $id, '_drb_service_category', sanitize_text_field( $item['subtitle'] ) ); update_post_meta( $id, '_drb_service_lead', sanitize_textarea_field( $item['description'] ) ); update_post_meta( $id, '_drb_source_name', 'dist6.zip' ); }
    }
    $stats = array(
        array( 'بازه سنی پذیرش', '۱۸–۴۵', 'سال تمام' ),
        array( 'فاصله جراحی ترمیمی', '۲۴ ماه', 'پس از جراحی قبلی' ),
        array( 'امکان پرواز', '۱۰ روز', 'پس از جراحی' ),
        array( 'پایان پذیرش', '۱۸:۰۰', 'بدون پذیرش پس از این ساعت' ),
    );
    foreach ( $stats as $index => $item ) {
        if ( get_page_by_title( $item[0], OBJECT, 'clinic_stat' ) ) continue;
        $id = wp_insert_post( array( 'post_type' => 'clinic_stat', 'post_status' => 'publish', 'post_title' => $item[0], 'post_content' => $item[2], 'menu_order' => $index ) );
        if ( $id && ! is_wp_error( $id ) ) { update_post_meta( $id, '_drb_stat_value', $item[1] ); update_post_meta( $id, '_drb_source_name', 'dist6.zip' ); }
    }
}

function drb_create_certificate_records( $media ) {
    foreach ( $media as $source => $attachment_id ) {
        if ( 0 !== strpos( $source, 'images/Certificates/' ) ) continue;
        $title = pathinfo( basename( $source ), PATHINFO_FILENAME );
        if ( get_page_by_title( $title, OBJECT, 'certificate' ) ) continue;
        $id = wp_insert_post( array( 'post_type' => 'certificate', 'post_status' => 'publish', 'post_title' => $title ) );
        if ( $id && ! is_wp_error( $id ) ) { set_post_thumbnail( $id, $attachment_id ); update_post_meta( $id, '_drb_source_name', 'dist6.zip' ); }
    }
}

function drb_assign_post_featured_images( $media ) {
    // Earlier builds recycled patient composites as generic article artwork.
    // Remove only those explicitly marked fallbacks; never touch an editor's image.
    foreach ( get_posts( array( 'post_type' => 'post', 'post_status' => 'any', 'posts_per_page' => -1, 'fields' => 'ids', 'meta_key' => '_drb_featured_fallback_source', 'meta_value' => 'dist6.zip' ) ) as $post_id ) {
        delete_post_thumbnail( $post_id );
        delete_post_meta( $post_id, '_drb_featured_fallback_source' );
    }
}

function drb_create_source_menu( $pages ) {
    $menu = wp_get_nav_menu_object( 'منوی اصلی دکتر باستانی‌نژاد' ); $menu_id = $menu ? $menu->term_id : wp_create_nav_menu( 'منوی اصلی دکتر باستانی‌نژاد' );
    if ( is_wp_error( $menu_id ) || wp_get_nav_menu_items( $menu_id ) ) return;
    foreach ( array( 'home', 'about', 'gallery', 'blog', 'faq', 'contact', 'booking' ) as $slug ) {
        if ( empty( $pages[ $slug ] ) ) continue;
        wp_update_nav_menu_item( $menu_id, 0, array( 'menu-item-object-id' => $pages[ $slug ], 'menu-item-object' => 'page', 'menu-item-type' => 'post_type', 'menu-item-status' => 'publish' ) );
    }
    $locations = get_theme_mod( 'nav_menu_locations', array() ); $locations['primary'] = $menu_id; set_theme_mod( 'nav_menu_locations', $locations );
    $front = get_page_by_title( 'صفحه اصلی', OBJECT, 'page' ); $blog = get_page_by_title( 'مقالات', OBJECT, 'page' );
    if ( $front ) { update_option( 'show_on_front', 'page' ); update_option( 'page_on_front', $front->ID ); }
    if ( $blog ) update_option( 'page_for_posts', $blog->ID );
}
