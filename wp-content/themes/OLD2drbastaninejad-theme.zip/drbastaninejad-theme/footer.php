<?php if ( function_exists( 'drb_use_native_template' ) && drb_use_native_template() ) : ?>
<?php $drb_footer_options = drb_get_theme_options(); ?>
<footer class="drb-native-footer bg-[#25272C] text-white mt-16" role="contentinfo">
    <div class="max-w-[1200px] mx-auto px-4 sm:px-6 py-10">
        <div class="drb-native-footer__grid">
            <div><img src="<?php echo esc_url( DRB_THEME_URI . '/assets/dist6/logo-white.svg' ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" width="190" height="58"><p class="text-white/70 text-sm">مرجع تخصصی جراحی طبیعی و عملکردی بینی</p></div>
            <div><h2>دسترسی سریع</h2><nav aria-label="منوی فوتر"><?php wp_nav_menu( array( 'theme_location' => 'footer', 'container' => false, 'fallback_cb' => false, 'menu_class' => 'drb-native-footer__menu' ) ); ?></nav></div>
            <div><h2>تماس با کلینیک</h2><p class="text-white/70 text-sm"><?php echo esc_html( $drb_footer_options['address'] ); ?></p><p class="text-white/70 text-sm"><?php echo esc_html( $drb_footer_options['clinic_hours'] ); ?></p><?php foreach ( array_values( array_filter( preg_split( '/\R+/', $drb_footer_options['phones'] ) ) ) as $drb_phone ) : ?><a class="drb-native-footer__phone" href="tel:<?php echo esc_attr( preg_replace( '/\D+/', '', $drb_phone ) ); ?>"><?php echo esc_html( $drb_phone ); ?></a><?php endforeach; ?></div>
        </div>
        <div class="drb-native-map-links" aria-label="مسیریاب‌ها">
            <?php
            $map_links = array(
                array( 'Google Maps', 'https://maps.google.com/?q=35.758881,51.413824', 'GoogleMap.webp' ),
                array( 'نشان', 'https://nshn.ir/gNbNgYZt_Rxg', 'Neshan.webp' ),
                array( 'بلد', 'https://balad.ir/p/3cuwGGif58f8hT', 'Balad.webp' ),
                array( 'Waze', 'https://waze.com/ul/htnke3vwqs', 'Waze.webp' ),
            );
            foreach ( $map_links as $map ) : ?>
                <a href="<?php echo esc_url( $map[1] ); ?>" target="_blank" rel="noopener noreferrer">
                    <img src="<?php echo esc_url( DRB_THEME_URI . '/assets/dist6/images/Icons/' . $map[2] ); ?>" alt="" width="20" height="20">
                    <span><?php echo esc_html( $map[0] ); ?></span>
                </a>
            <?php endforeach; ?>
        </div>
        <div class="drb-native-footer__bottom"><span>© <?php echo esc_html( wp_date( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?></span><span>نتایج درمان در افراد مختلف متفاوت است.</span></div>
    </div>
</footer>
<?php endif; ?>
<?php wp_footer(); ?>
</body>
</html>
