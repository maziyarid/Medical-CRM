<!doctype html>
<html <?php language_attributes(); ?> dir="rtl">
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="screen-reader-text" href="#root"><?php esc_html_e( 'پرش به محتوای اصلی', 'drb-theme' ); ?></a>
<?php if ( function_exists( 'drb_use_native_template' ) && drb_use_native_template() ) : ?>
<header class="site-nav drb-native-header bg-white border-b border-[#DDE2DD]">
    <div class="max-w-[1200px] mx-auto px-4 sm:px-6 h-full flex items-center justify-between gap-5">
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="flex-shrink-0" aria-label="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
            <img src="<?php echo esc_url( DRB_THEME_URI . '/assets/dist6/logo.svg' ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" style="width:180px;height:52px;object-fit:contain">
        </a>
        <nav aria-label="منوی اصلی" class="hidden md:block"><?php wp_nav_menu( array( 'theme_location' => 'primary', 'container' => false, 'fallback_cb' => false, 'menu_class' => 'flex items-center gap-5 text-sm font-semibold text-[#25272C]' ) ); ?></nav>
        <div class="drb-native-header__actions">
            <a href="<?php echo esc_url( home_url( '/booking/' ) ); ?>" class="button button--primary">دریافت نوبت</a>
            <details class="drb-native-menu md:hidden"><summary aria-label="باز کردن منوی سایت">منو</summary><nav aria-label="منوی موبایل"><?php wp_nav_menu( array( 'theme_location' => 'primary', 'container' => false, 'fallback_cb' => false, 'menu_class' => 'drb-native-menu__list' ) ); ?></nav></details>
        </div>
    </div>
</header>
<?php if ( function_exists( 'drb_render_nutrition_quicklink' ) ) drb_render_nutrition_quicklink( true ); ?>
<?php endif; ?>
