<?php get_header(); if ( is_singular( 'post' ) ) get_template_part( 'template-parts/native-single' ); else get_template_part( 'template-parts/app-shell' ); get_footer();
