<?php
defined( 'ABSPATH' ) || exit;

function drb_admin_assets( $hook ) {
    if ( false === strpos( $hook, 'drb' ) && ! in_array( $hook, array( 'index.php', 'post.php', 'post-new.php' ), true ) ) return;
    wp_enqueue_style( 'drb-admin', DRB_THEME_URI . '/assets/admin.css', array(), DRB_THEME_VERSION );
    wp_enqueue_media(); wp_enqueue_script( 'drb-admin', DRB_THEME_URI . '/assets/admin.js', array( 'jquery' ), DRB_THEME_VERSION, true );
}
add_action( 'admin_enqueue_scripts', 'drb_admin_assets' );

function drb_dashboard_widgets() {
    wp_add_dashboard_widget( 'drb_content_overview', 'وضعیت محتوای سایت', 'drb_widget_content_overview' );
    wp_add_dashboard_widget( 'drb_source_integrity', 'یکپارچگی منبع و رسانه', 'drb_widget_source_integrity' );
    wp_add_dashboard_widget( 'drb_leads_overview', 'پیام‌ها و درخواست‌های نوبت', 'drb_widget_leads_overview' );
    wp_add_dashboard_widget( 'drb_gallery_readiness', 'آمادگی گالری قبل و بعد', 'drb_widget_gallery_readiness' );
    wp_add_dashboard_widget( 'drb_public_stats', 'آمار عمومی نمایش‌داده‌شده در سایت', 'drb_widget_public_stats' );
}

function drb_widget_public_stats() {
    $rows = array();
    foreach ( get_posts( array( 'post_type' => 'clinic_stat', 'post_status' => 'publish', 'posts_per_page' => -1, 'orderby' => array( 'menu_order' => 'ASC', 'date' => 'ASC' ) ) ) as $item ) {
        $rows[] = array( get_the_title( $item ), get_post_meta( $item->ID, '_drb_stat_value', true ), get_edit_post_link( $item->ID ) );
    }
    if ( ! $rows ) { echo '<p>آمار هنوز وارد نشده است.</p>'; return; }
    echo '<div class="drb-stat-rows">'; foreach ( $rows as $row ) echo '<a href="' . esc_url( $row[2] ) . '"><span>' . esc_html( $row[0] ) . '</span><strong>' . esc_html( $row[1] ) . '</strong></a>'; echo '</div>';
    echo '<p class="description">هر عدد را فقط بر اساس مدرک قابل اتکا ویرایش یا منتشر کنید.</p>';
}
add_action( 'wp_dashboard_setup', 'drb_dashboard_widgets' );

function drb_count_status( $type, $status = 'publish' ) { $c = wp_count_posts( $type ); return isset( $c->$status ) ? (int) $c->$status : 0; }

function drb_widget_content_overview() {
    $rows = array(
        array( 'نوشته‌های منتشرشده', drb_count_status( 'post' ), admin_url( 'edit.php' ) ),
        array( 'صفحات منتشرشده', drb_count_status( 'page' ), admin_url( 'edit.php?post_type=page' ) ),
        array( 'خدمات', drb_count_status( 'service' ), admin_url( 'edit.php?post_type=service' ) ),
        array( 'سؤالات متداول', drb_count_status( 'clinic_faq' ), admin_url( 'edit.php?post_type=clinic_faq' ) ),
        array( 'گواهینامه‌ها', drb_count_status( 'certificate' ), admin_url( 'edit.php?post_type=certificate' ) ),
    ); drb_render_stat_rows( $rows );
    echo '<p class="drb-widget-actions"><a class="button button-primary" href="' . esc_url( admin_url( 'themes.php?page=drb-source-import' ) ) . '">بررسی منبع اصلی</a> <a class="button" href="' . esc_url( admin_url( 'themes.php?page=drb-theme-options' ) ) . '">تنظیمات کلینیک</a></p>';
}

function drb_widget_source_integrity() {
    $s = drb_source_status(); $m = $s['manifest']; $bundled = count( drb_dist6_media_files() );
    $rows = array(
        array( 'نوشته مورد انتظار', (int) ( $m['importable_posts'] ?? 0 ), '' ),
        array( 'صفحه مورد انتظار', (int) ( $m['importable_pages'] ?? 0 ), '' ),
        array( 'FAQ استخراج‌شده', (int) ( $m['faq_count'] ?? 0 ), '' ),
        array( 'رسانه غیر بیمار بسته', $bundled, admin_url( 'upload.php' ) ),
    ); drb_render_stat_rows( $rows );
    echo '<p><strong>آخرین همگام‌سازی:</strong> ' . esc_html( $s['imported_at'] ?: 'انجام نشده' ) . '</p>';
    echo '<p><strong>Rank Math:</strong> ' . ( defined( 'RANK_MATH_VERSION' ) ? '<span class="drb-ok">فعال</span>' : '<span class="drb-warn">فعال نیست</span>' ) . '</p>';
}

function drb_widget_leads_overview() {
    $total = drb_count_status( 'drb_submission', 'private' );
    $week = new WP_Query( array( 'post_type' => 'drb_submission', 'post_status' => 'private', 'posts_per_page' => 1, 'date_query' => array( array( 'after' => '7 days ago' ) ), 'fields' => 'ids' ) );
    drb_render_stat_rows( array( array( 'کل درخواست‌ها', $total, admin_url( 'edit.php?post_type=drb_submission' ) ), array( 'هفت روز اخیر', (int) $week->found_posts, admin_url( 'edit.php?post_type=drb_submission' ) ) ) );
    echo '<p>درخواست‌ها خصوصی‌اند و فقط کاربران مجاز مدیریت به آن‌ها دسترسی دارند.</p>';
}

function drb_widget_gallery_readiness() {
    $verified = get_posts( array( 'post_type' => 'case_study', 'post_status' => 'publish', 'posts_per_page' => -1, 'fields' => 'ids', 'meta_key' => '_drb_consent_verified', 'meta_value' => '1' ) );
    $all = drb_count_status( 'case_study' ); $options = drb_get_theme_options();
    drb_render_stat_rows( array( array( 'کل نمونه‌ها', $all, admin_url( 'edit.php?post_type=case_study' ) ), array( 'دارای رضایت معتبر', count( $verified ), admin_url( 'edit.php?post_type=case_study' ) ) ) );
    echo '<p><strong>انتشار عمومی:</strong> ' . ( ! empty( $options['gallery_enabled'] ) ? '<span class="drb-ok">فعال</span>' : '<span class="drb-warn">خاموش</span>' ) . '</p>';
    echo '<p><a class="button" href="' . esc_url( admin_url( 'post-new.php?post_type=case_study' ) ) . '">افزودن نمونه امن</a></p>';
}

function drb_render_stat_rows( $rows ) { echo '<div class="drb-stat-rows">'; foreach ( $rows as $row ) { echo '<a ' . ( $row[2] ? 'href="' . esc_url( $row[2] ) . '"' : '' ) . '><span>' . esc_html( $row[0] ) . '</span><strong>' . number_format_i18n( $row[1] ) . '</strong></a>'; } echo '</div>'; }

function drb_admin_bar_health( WP_Admin_Bar $bar ) {
    if ( ! current_user_can( 'manage_options' ) ) return;
    $s = drb_source_status(); $expected = (int) ( $s['manifest']['importable_posts'] ?? 0 ); $ok = $expected && $s['posts'] >= $expected;
    $bar->add_node( array( 'id' => 'drb-health', 'title' => $ok ? 'کلینیک: آماده' : 'کلینیک: نیازمند همگام‌سازی', 'href' => admin_url( 'themes.php?page=drb-source-import' ) ) );
}
add_action( 'admin_bar_menu', 'drb_admin_bar_health', 90 );
