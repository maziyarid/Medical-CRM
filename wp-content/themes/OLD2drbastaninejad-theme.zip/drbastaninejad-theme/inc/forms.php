<?php
defined( 'ABSPATH' ) || exit;

function drb_register_form_routes() {
    foreach ( array( 'contact', 'appointment' ) as $kind ) {
        register_rest_route( 'drb/v1', '/' . $kind, array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => function( WP_REST_Request $request ) use ( $kind ) { return drb_process_submission( $request, $kind ); },
            'permission_callback' => '__return_true',
        ) );
    }
}
add_action( 'rest_api_init', 'drb_register_form_routes' );

function drb_process_submission( WP_REST_Request $request, $kind ) {
    $data = (array) $request->get_json_params();
    if ( ! empty( $data['website'] ) ) return new WP_Error( 'spam', 'درخواست نامعتبر است.', array( 'status' => 400 ) );
    $ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'unknown';
    $rate_key = 'drb_rate_' . md5( $ip . '|' . $kind );
    $count = (int) get_transient( $rate_key );
    if ( $count >= 5 ) return new WP_Error( 'rate_limited', 'تعداد درخواست‌ها بیش از حد مجاز است. کمی بعد دوباره تلاش کنید.', array( 'status' => 429 ) );
    set_transient( $rate_key, $count + 1, 10 * MINUTE_IN_SECONDS );

    $name  = sanitize_text_field( $data['name'] ?? $data['fullName'] ?? '' );
    $phone = preg_replace( '/[^0-9۰-۹+]/u', '', (string) ( $data['phone'] ?? '' ) );
    $email = sanitize_email( $data['email'] ?? '' );
    if ( strlen( $name ) < 2 || strlen( $phone ) < 7 ) {
        return new WP_Error( 'invalid_fields', 'نام و شماره تماس معتبر الزامی است.', array( 'status' => 422 ) );
    }
    if ( $email && ! is_email( $email ) ) return new WP_Error( 'invalid_email', 'ایمیل معتبر نیست.', array( 'status' => 422 ) );

    if ( 'appointment' === $kind ) {
        $to_latin = static function( $value ) {
            return strtr( (string) $value, array( '۰'=>'0', '۱'=>'1', '۲'=>'2', '۳'=>'3', '۴'=>'4', '۵'=>'5', '۶'=>'6', '۷'=>'7', '۸'=>'8', '۹'=>'9' ) );
        };
        $age = absint( $to_latin( $data['age'] ?? 0 ) );
        if ( $age < 18 || $age > 45 ) {
            return new WP_Error( 'ineligible_age', 'پذیرش جراحی فقط برای بازه سنی ۱۸ تا ۴۵ سال انجام می‌شود.', array( 'status' => 422 ) );
        }
        if ( empty( $data['eligibilityConfirmed'] ) || ! in_array( (string) $data['eligibilityConfirmed'], array( '1', 'true', 'yes', 'on' ), true ) ) {
            return new WP_Error( 'eligibility_required', 'تأیید شرایط پذیرش الزامی است.', array( 'status' => 422 ) );
        }
        $procedure = sanitize_text_field( $data['procedure'] ?? $data['service'] ?? '' );
        if ( false !== mb_strpos( $procedure, 'ترمیمی' ) ) {
            $months = absint( $to_latin( $data['previousSurgeryMonths'] ?? 0 ) );
            if ( $months < 24 ) {
                return new WP_Error( 'revision_too_soon', 'بررسی جراحی ترمیمی فقط پس از گذشت کامل ۲۴ ماه از جراحی قبلی انجام می‌شود.', array( 'status' => 422 ) );
            }
        }
    }

    $allowed = array( 'name', 'fullName', 'phone', 'email', 'subject', 'message', 'service', 'procedure', 'preferredDate', 'preferredTime', 'preferred_date', 'preferred_time', 'age', 'city', 'previousSurgery', 'previousSurgeryMonths', 'eligibilityConfirmed', 'notes' );
    $clean = array();
    foreach ( $allowed as $key ) if ( isset( $data[ $key ] ) ) $clean[ $key ] = sanitize_textarea_field( (string) $data[ $key ] );
    $labels = array( 'contact' => 'پیام تماس', 'appointment' => 'درخواست نوبت' );
    $body = '';
    foreach ( $clean as $key => $value ) $body .= '<p><strong>' . esc_html( $key ) . ':</strong> ' . nl2br( esc_html( $value ) ) . '</p>';
    $post_id = wp_insert_post( array( 'post_type' => 'drb_submission', 'post_status' => 'private', 'post_title' => $labels[ $kind ] . ' — ' . $name, 'post_content' => $body ) );
    if ( is_wp_error( $post_id ) || ! $post_id ) return new WP_Error( 'save_failed', 'ثبت درخواست انجام نشد.', array( 'status' => 500 ) );
    update_post_meta( $post_id, '_drb_submission_type', $kind );
    update_post_meta( $post_id, '_drb_phone', $phone );
    if ( $email ) update_post_meta( $post_id, '_drb_email', $email );
    wp_mail( get_option( 'admin_email' ), $labels[ $kind ] . ' جدید: ' . $name, wp_strip_all_tags( $body ) );
    do_action( 'drb_submission_created', $post_id, $kind, $clean );
    return new WP_REST_Response( array( 'success' => true, 'message' => 'درخواست شما با موفقیت ثبت شد.', 'submissionId' => $post_id ), 201 );
}
