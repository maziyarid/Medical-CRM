<?php get_header(); if ( drb_use_native_template() ) get_template_part( 'template-parts/native-archive' ); else get_template_part( 'template-parts/app-shell' ); get_footer();
