<?php

defined( 'ABSPATH' ) || exit;

define( 'DRB_THEME_VERSION', '4.3.0' );
define( 'DRB_THEME_DIR', get_template_directory() );
define( 'DRB_THEME_URI', get_template_directory_uri() );

require_once DRB_THEME_DIR . '/inc/setup.php';
require_once DRB_THEME_DIR . '/inc/content-types.php';
require_once DRB_THEME_DIR . '/inc/meta-boxes.php';
require_once DRB_THEME_DIR . '/inc/options.php';
require_once DRB_THEME_DIR . '/inc/content-policy.php';
require_once DRB_THEME_DIR . '/inc/source-importer.php';
require_once DRB_THEME_DIR . '/inc/rank-math.php';
require_once DRB_THEME_DIR . '/inc/forms.php';
require_once DRB_THEME_DIR . '/inc/seo.php';
require_once DRB_THEME_DIR . '/inc/tracking.php';
require_once DRB_THEME_DIR . '/inc/admin-dashboard.php';
require_once DRB_THEME_DIR . '/inc/case-management.php';
require_once DRB_THEME_DIR . '/inc/react-app.php';
