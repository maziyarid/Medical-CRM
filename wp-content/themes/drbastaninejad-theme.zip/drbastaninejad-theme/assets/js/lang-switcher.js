(function () {
  function closeAll(except) {
    document.querySelectorAll('[data-drb-langdd].is-open').forEach(function (el) {
      if (except && el === except) return;
      el.classList.remove('is-open');
      var btn = el.querySelector('.drb-langdd__btn');
      var menu = el.querySelector('.drb-langdd__menu');
      if (btn) btn.setAttribute('aria-expanded', 'false');
      if (menu) menu.hidden = true;
    });
  }

  function initOne(root) {
    var btn = root.querySelector('.drb-langdd__btn');
    var menu = root.querySelector('.drb-langdd__menu');
    if (!btn || !menu) return;

    btn.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      var open = !root.classList.contains('is-open');
      closeAll(root);
      root.classList.toggle('is-open', open);
      btn.setAttribute('aria-expanded', open ? 'true' : 'false');
      menu.hidden = !open;
    });

    btn.addEventListener('keydown', function (e) {
      if (e.key === 'ArrowDown' || e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        root.classList.add('is-open');
        btn.setAttribute('aria-expanded', 'true');
        menu.hidden = false;
        var first = menu.querySelector('a');
        if (first) first.focus();
      }
    });
  }

  document.addEventListener('click', function () { closeAll(); });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') closeAll();
  });

  function boot() {
    document.querySelectorAll('[data-drb-langdd]').forEach(initOne);
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
