<?php
/**
 * DrB no-plugin multilingual core
 * Host/subdomain detection + PHP language packs + post meta association.
 * Languages: fa (default RTL), en, ar (RTL), tr, ru, fr, de, es (LTR)
 *
 * URL strategy:
 *   fa  → https://drbastaninejad.com/
 *   en  → https://en.drbastaninejad.com/
 *   ar  → https://ar.drbastaninejad.com/
 *   tr  → https://tr.drbastaninejad.com/
 *   ru  → https://ru.drbastaninejad.com/
 *   fr  → https://fr.drbastaninejad.com/
 *   de  → https://de.drbastaninejad.com/
 *   es  → https://es.drbastaninejad.com/
 *
 * Association: post meta drb_lang_code + drb_lang_group_id
 * Fallback for local/dev: ?lang=xx
 */

if (!defined('ABSPATH')) {
    exit;
}

define('DRB_LANGS', ['fa', 'en', 'ar', 'tr', 'ru', 'fr', 'de', 'es']);
define('DRB_RTL_LANGS', ['fa', 'ar']);
define('DRB_DEFAULT_LANG', 'fa');

/**
 * Detect language from HTTP_HOST subdomain. Fallback to ?lang= then default.
 */
function drb_detect_lang(): string
{
    static $lang = null;
    if ($lang !== null) {
        return $lang;
    }

    $host = strtolower((string)($_SERVER['HTTP_HOST'] ?? ''));
    $host = preg_replace('/:\d+$/', '', $host); // strip port

    // Subdomain map
    $map = [
        'en.drbastaninejad.com' => 'en',
        'ar.drbastaninejad.com' => 'ar',
        'tr.drbastaninejad.com' => 'tr',
        'ru.drbastaninejad.com' => 'ru',
        'fr.drbastaninejad.com' => 'fr',
        'de.drbastaninejad.com' => 'de',
        'es.drbastaninejad.com' => 'es',
        'drbastaninejad.com'    => 'fa',
        'www.drbastaninejad.com'=> 'fa',
    ];
    if (isset($map[$host])) {
        $lang = $map[$host];
        return $lang;
    }

    // Temporary query fallback for DNS-not-yet-live environments
    $q = isset($_GET['lang']) ? strtolower(sanitize_text_field(wp_unslash($_GET['lang']))) : '';
    if (in_array($q, DRB_LANGS, true)) {
        $lang = $q;
        return $lang;
    }

    $lang = DRB_DEFAULT_LANG;
    return $lang;
}

function drb_is_rtl(?string $lang = null): bool
{
    $lang = $lang ?? drb_detect_lang();
    return in_array($lang, DRB_RTL_LANGS, true);
}

function drb_html_lang(?string $lang = null): string
{
    $lang = $lang ?? drb_detect_lang();
    $map = [
        'fa' => 'fa-IR',
        'en' => 'en',
        'ar' => 'ar',
        'tr' => 'tr',
        'ru' => 'ru',
        'fr' => 'fr',
        'de' => 'de',
        'es' => 'es',
    ];
    return $map[$lang] ?? $lang;
}

/**
 * Load language pack once.
 */
function drb_load_pack(?string $lang = null): array
{
    static $packs = [];
    $lang = $lang ?? drb_detect_lang();
    if (isset($packs[$lang])) {
        return $packs[$lang];
    }
    $file = get_template_directory() . '/languages/' . $lang . '.php';
    $pack = [];
    if (is_readable($file)) {
        $loaded = include $file;
        if (is_array($loaded)) {
            $pack = $loaded;
        }
    }
    // Always ensure FA pack is available as ultimate fallback
    if ($lang !== 'fa' && !isset($packs['fa'])) {
        $fa = get_template_directory() . '/languages/fa.php';
        if (is_readable($fa)) {
            $packs['fa'] = include $fa;
            if (!is_array($packs['fa'])) {
                $packs['fa'] = [];
            }
        }
    }
    $packs[$lang] = $pack;
    return $pack;
}

/**
 * Translate helper. Usage: __t('nav_home') or theme_t('nav_home')
 */
function __t(string $key, ?string $lang = null): string
{
    $pack = drb_load_pack($lang);
    if (isset($pack[$key]) && $pack[$key] !== '') {
        return (string)$pack[$key];
    }
    // Fallback to Persian
    $fa = drb_load_pack('fa');
    return (string)($fa[$key] ?? $key);
}

function theme_t(string $key, ?string $lang = null): string
{
    return __t($key, $lang);
}

/**
 * Build absolute URL for the same logical page in another language.
 * Uses post meta drb_lang_group_id + drb_lang_code when available.
 */
function drb_lang_url(string $target_lang, $post_id = null): string
{
    $hosts = [
        'fa' => 'https://drbastaninejad.com',
        'en' => 'https://en.drbastaninejad.com',
        'ar' => 'https://ar.drbastaninejad.com',
        'tr' => 'https://tr.drbastaninejad.com',
        'ru' => 'https://ru.drbastaninejad.com',
        'fr' => 'https://fr.drbastaninejad.com',
        'de' => 'https://de.drbastaninejad.com',
        'es' => 'https://es.drbastaninejad.com',
    ];
    $base = $hosts[$target_lang] ?? $hosts['fa'];

    if (!$post_id) {
        $post_id = get_queried_object_id();
    }
    if (!$post_id) {
        return $base . '/';
    }

    $group = get_post_meta($post_id, 'drb_lang_group_id', true);
    if ($group) {
        $q = new WP_Query([
            'post_type'      => get_post_type($post_id) ?: 'page',
            'post_status'    => 'publish',
            'posts_per_page' => 1,
            'fields'         => 'ids',
            'meta_query'     => [
                'relation' => 'AND',
                [
                    'key'   => 'drb_lang_group_id',
                    'value' => $group,
                ],
                [
                    'key'   => 'drb_lang_code',
                    'value' => $target_lang,
                ],
            ],
            'no_found_rows'  => true,
        ]);
        if (!empty($q->posts)) {
            $sibling = (int)$q->posts[0];
            $path = wp_make_link_relative(get_permalink($sibling));
            // Strip host if any
            $path = preg_replace('#^https?://[^/]+#', '', $path);
            return rtrim($base, '/') . $path;
        }
    }

    // Fallback: same path on target host (works when slugs are language-neutral
    // or when content has not yet been associated).
    $path = wp_make_link_relative(get_permalink($post_id));
    $path = preg_replace('#^https?://[^/]+#', '', $path);
    return rtrim($base, '/') . ($path ?: '/');
}

/**
 * Language switcher markup (desktop + mobile friendly).
 */
function drb_language_switcher(string $context = 'header'): string
{
    $current = drb_detect_lang();
    $labels = [
        'fa' => 'فارسی',
        'en' => 'English',
        'ar' => 'العربية',
        'tr' => 'Türkçe',
        'ru' => 'Русский',
        'fr' => 'Français',
        'de' => 'Deutsch',
        'es' => 'Español',
    ];
    $html = '<nav class="drb-lang-switcher drb-lang-switcher--' . esc_attr($context) . '" aria-label="' . esc_attr(__t('lang_switcher_label')) . '">';
    $html .= '<ul class="drb-lang-list">';
    foreach (DRB_LANGS as $code) {
        $url = esc_url(drb_lang_url($code));
        $active = $code === $current ? ' is-active' : '';
        $html .= '<li class="drb-lang-item' . $active . '">';
        $html .= '<a href="' . $url . '" hreflang="' . esc_attr($code) . '" lang="' . esc_attr($code) . '">';
        $html .= esc_html($labels[$code] ?? strtoupper($code));
        $html .= '</a></li>';
    }
    $html .= '</ul></nav>';
    return $html;
}

/**
 * Output <link rel="alternate" hreflang="..."> for all languages + x-default.
 */
function drb_output_hreflang(): void
{
    $post_id = get_queried_object_id();
    foreach (DRB_LANGS as $code) {
        $url = drb_lang_url($code, $post_id ?: null);
        echo '<link rel="alternate" hreflang="' . esc_attr($code) . '" href="' . esc_url($url) . '" />' . "\n";
    }
    echo '<link rel="alternate" hreflang="x-default" href="' . esc_url(drb_lang_url('fa', $post_id ?: null)) . '" />' . "\n";
}

/**
 * Set document language + direction early.
 */
function drb_bootstrap_html_attrs(): void
{
    // Filters for themes that use language_attributes()
    add_filter('language_attributes', function ($output) {
        $lang = drb_html_lang();
        $dir  = drb_is_rtl() ? 'rtl' : 'ltr';
        return 'lang="' . esc_attr($lang) . '" dir="' . esc_attr($dir) . '"';
    });
}

add_action('after_setup_theme', 'drb_bootstrap_html_attrs', 1);
add_action('wp_head', 'drb_output_hreflang', 2);

/**
 * Admin helper: when saving a page, allow setting lang code + group.
 * (Simple meta boxes; no plugin.)
 */
function drb_register_lang_meta(): void
{
    register_post_meta('page', 'drb_lang_code', [
        'type' => 'string',
        'single' => true,
        'show_in_rest' => true,
        'auth_callback' => function () {
            return current_user_can('edit_pages');
        },
    ]);
    register_post_meta('page', 'drb_lang_group_id', [
        'type' => 'string',
        'single' => true,
        'show_in_rest' => true,
        'auth_callback' => function () {
            return current_user_can('edit_pages');
        },
    ]);
}
add_action('init', 'drb_register_lang_meta');

/**
 * Convenience: filter body class for LTR/RTL chrome.
 */
add_filter('body_class', function ($classes) {
    $classes[] = drb_is_rtl() ? 'drb-rtl' : 'drb-ltr';
    $classes[] = 'drb-lang-' . drb_detect_lang();
    return $classes;
});
