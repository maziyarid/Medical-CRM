<?php
declare(strict_types=1);
namespace App;
use RuntimeException;
final class OtpService {
    public function send(string $phone,string $ip): array {
        $phone=Security::mobile($phone); $this->rateLimit($phone,$ip);
        $length=max(4,min(6,(int)env('SMS_OTP_LENGTH','5'))); $demo=strtolower((string)env('SMS_PROVIDER','tsms'))==='demo';
        $code=$demo?str_pad((string)env('SMS_DEMO_CODE','12345'),$length,'0',STR_PAD_LEFT):str_pad((string)random_int(0,(10**$length)-1),$length,'0',STR_PAD_LEFT);
        $token=bin2hex(random_bytes(24)); $ttl=max(60,min(600,(int)env('SMS_OTP_TTL_SECONDS','180')));
        $template=(string)env('SMS_MESSAGE_TEMPLATE',"کد تشکیل پرونده: {{code}}\n@app.drbastaninejad.com #{{code}}");
        $message=strtr($template,['{{code}}'=>$code,'{{phone}}'=>$phone]);
        $record=['token'=>$token,'phone'=>$phone,'code_hash'=>password_hash($code,PASSWORD_DEFAULT),'ip'=>$ip,'status'=>'pending','attempts'=>0,'expires_at'=>time()+$ttl,'created_at'=>time()];
        $this->save($record);
        try { $sent=(new TsmsClient())->send($phone,$message); $record['status']='sent'; $record['message_id']=$sent['messageId']??''; $this->save($record); }
        catch(\Throwable $e){ $record['status']='failed';$record['error']=$e->getMessage();$this->save($record);throw $e; }
        return ['success'=>true,'token'=>$token,'expiresIn'=>$ttl,'message'=>'کد تأیید ارسال شد.'];
    }
    public function verify(string $phone,string $token,string $code): array {
        $phone=Security::mobile($phone); $token=preg_replace('/[^a-f0-9]/i','',$token)??''; $code=Security::digits($code); $r=$this->load($token);
        if(!$r||($r['phone']??'')!==$phone||!in_array($r['status']??'',['sent','verified'],true))throw new RuntimeException('درخواست کد معتبر نیست.');
        if((int)$r['expires_at']<time())throw new RuntimeException('کد منقضی شده است.');
        if((int)($r['attempts']??0)>=(int)env('OTP_MAX_ATTEMPTS','5'))throw new RuntimeException('تعداد تلاش بیش از حد مجاز است.');
        if(!password_verify($code,(string)$r['code_hash'])){$r['attempts']=(int)($r['attempts']??0)+1;$this->save($r);throw new RuntimeException('کد تأیید نادرست است.');}
        $r['status']='verified';$r['verified_at']=time();$this->save($r);return ['success'=>true,'token'=>$token,'message'=>'شماره با موفقیت تأیید شد.'];
    }
    public function assertVerified(string $phone,string $token): array { $phone=Security::mobile($phone);$r=$this->load($token);if(!$r||($r['phone']??'')!==$phone||($r['status']??'')!=='verified')throw new RuntimeException('تأیید شماره معتبر نیست؛ دوباره کد بگیرید.');if((int)$r['expires_at']<time())throw new RuntimeException('کد منقضی شده است.');return $r; }
    public function consume(string $token): void { $r=$this->load($token);if($r){$r['status']='consumed';$r['consumed_at']=time();$this->save($r);} }
    private function path(string $token): string { return APP_ROOT.'/storage/otp/'.$token.'.json'; }
    private function load(string $token): ?array { if(!preg_match('/^[a-f0-9]{48}$/i',$token))return null;$d=json_decode((string)@file_get_contents($this->path($token)),true);return is_array($d)?$d:null; }
    private function save(array $record): void { $json=json_encode($record,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);if($json===false||file_put_contents($this->path((string)$record['token']),$json,LOCK_EX)===false)throw new RuntimeException('فضای ذخیره OTP قابل نوشتن نیست.');@chmod($this->path((string)$record['token']),0640); }
    private function rateLimit(string $phone,string $ip): void { $pc=0;$ic=0;$now=time();foreach(glob(APP_ROOT.'/storage/otp/*.json')?:[] as $file){$r=json_decode((string)@file_get_contents($file),true);if(!is_array($r))continue;$created=(int)($r['created_at']??0);if($created&&$now-$created>86400){@unlink($file);continue;}if(($r['phone']??'')===$phone&&$now-$created<=600)$pc++;if(($r['ip']??'')===$ip&&$now-$created<=3600)$ic++;}if($pc>=(int)env('OTP_PHONE_LIMIT_10_MIN','3'))throw new RuntimeException('تعداد درخواست کد برای این شماره زیاد است. کمی بعد تلاش کنید.');if($ic>=(int)env('OTP_IP_LIMIT_60_MIN','10'))throw new RuntimeException('محدودیت ارسال کد برای این اتصال فعال شده است.'); }
}
